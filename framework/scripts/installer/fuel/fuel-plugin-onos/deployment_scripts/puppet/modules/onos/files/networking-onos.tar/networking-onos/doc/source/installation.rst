============
Installation
============

At the command line::

    $ pip install networking-onos

Or, if you have virtualenvwrapper installed::

    $ mkvirtualenv networking-onos
    $ pip install networking-onos
